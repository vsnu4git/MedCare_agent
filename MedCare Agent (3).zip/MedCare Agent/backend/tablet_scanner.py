import base64, json, re
from backend.config import client

def clean_json_response(text):
    text = re.sub(r"^```(?:json)?", "", text.strip(), flags=re.IGNORECASE)
    text = re.sub(r"```$", "", text.strip())
    text = text.replace("'", '"')
    return text.strip()

def identify_tablet(image_path):
    with open(image_path, "rb") as f:
        image_bytes = f.read()
    b64 = base64.b64encode(image_bytes).decode("utf-8")

    response = client.responses.create(
        model="gpt-4o-mini",
        input=[{
            "role": "user",
            "content": [
                {"type": "input_text", "text": (
                    "Identify this tablet based on imprint, color, and shape. "
                    "Return JSON: {'tablet':{'name':'Paracetamol','dosage':'500mg','manufacturer':'Cipla'}}"
                )},
                {"type": "input_image", "image_url": f"data:image/jpeg;base64,{b64}"}
            ]
        }],
        max_output_tokens=500
    )
    cleaned = clean_json_response(response.output_text)
    try:
        return json.loads(cleaned).get("tablet", {})
    except json.JSONDecodeError:
        print("⚠ Invalid JSON response:", response.output_text)
        return {}
