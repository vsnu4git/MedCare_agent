import streamlit as st
import tempfile
import os
import base64
from openai import OpenAI
from backend.config import client

def doctor_realtime_voice():
    st.subheader("🎙️ Real-Time Doctor Voice Assistant")

    audio_file = st.audio_input("Talk to Doctor AI in real time")

    if audio_file is not None:
        audio_bytes = audio_file.getvalue()

        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_audio:
            temp_audio.write(audio_bytes)
            temp_audio_path = temp_audio.name

        st.success("✅ Audio received. Processing your question...")

        transcription = client.audio.transcriptions.create(
            model="gpt-4o-mini-transcribe",
            file=open(temp_audio_path, "rb")
        )

        query_text = transcription.text
        st.write(f"🗣️ You said: {query_text}")

        # Get text answer
        response = client.responses.create(
            model="gpt-4o-mini",
            input=f"You are an AI doctor. Respond concisely to: {query_text}"
        )

        reply_text = response.output_text

        # Generate voice reply
        tts = client.audio.speech.create(
            model="gpt-4o-mini-tts",
            voice="alloy",
            input=reply_text
        )

        reply_audio_path = "doctor_reply.mp3"
        tts.stream_to_file(reply_audio_path)

        st.audio(reply_audio_path)
        st.info("👩‍⚕️ Doctor AI has replied.")

        os.remove(temp_audio_path)
