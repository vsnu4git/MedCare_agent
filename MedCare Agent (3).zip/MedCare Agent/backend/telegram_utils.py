import requests
from backend.config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID

def send_telegram_message(med_name, med_dosage, med_time):
    """Send a medicine reminder message to Telegram."""
    message = f"💊 Reminder: Take {med_name} ({med_dosage}) at {med_time}"
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message,
        "parse_mode": "Markdown"
    }
    try:
        res = requests.post(url, data=payload, timeout=10)
        res.raise_for_status()
        print(f"📨 Message sent successfully for {med_name} ({med_dosage}) at {med_time}")
    except requests.exceptions.RequestException as e:
        print(f"⚠ Failed to send message: {e}")
        if 'res' in locals():
            print("Response:", res.text)
