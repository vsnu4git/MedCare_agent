from fastapi import FastAPI
from pydantic import BaseModel
from backend.voice_assistant import doctor_realtime_voice
from backend.tablet_scanner import identify_tablet
from backend.prescription_scanner import process_prescription
from backend.telegram_utils import send_telegram_message
             
app = FastAPI()

class Query(BaseModel):
    question: str 

@app.post("/rag")
def rag_endpoint(query: Query):
    try:
        response = doctor_realtime_voice(query.question)
        return {"answer": response}
    except Exception as e:
        return {"error": str(e)}

@app.get("/")
def home():
    return {"message": "MedCare Agent RAG API is running ✅"}
