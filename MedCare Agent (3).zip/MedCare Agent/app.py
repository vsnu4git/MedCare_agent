import streamlit as st
from backend.voice_assistant import doctor_realtime_voice
from backend.tablet_scanner import identify_tablet 
from backend.prescription_scanner import process_prescription 
from backend.config import client 

st.set_page_config(page_title="MedCare Agent", page_icon="💊", layout="wide") 

st.title("MedCare Agent") 

tab1, tab2, tab3, tab4 = st.tabs(["🩺 Doctor Chatbot", "🎙️ Voice Assistant", "📷 Prescription Scanner", "💊 Tablet Scanner"])

# 1️⃣ Doctor Chatbot
with tab1:
    st.subheader("Chat with AI Doctor")
    user_input = st.text_input("Ask your question:")
    if st.button("Send", key="chat"):
        if user_input:
            reply = client.responses.create(
                model="gpt-4o-mini",
                input=f"You are a helpful medical assistant. {user_input}",
                max_output_tokens=400
            )
            st.success(reply.output_text)

# 2️⃣ Voice Assistant
# 2️⃣ Voice Assistant (Realtime-like)
with tab2:
    doctor_realtime_voice()




# 3️⃣ Prescription Scanner
with tab3:
    st.subheader("Upload Prescription Image")
    image_file = st.file_uploader("Upload prescription", type=["jpg", "png", "jpeg"])
    if st.button("Scan Prescription"):
        if image_file:
            with open("prescription.jpg", "wb") as f:
                f.write(image_file.read())
            process_prescription("prescription.jpg")

# 4️⃣ Tablet Scanner
with tab4:
    st.subheader("Upload Tablet Image")
    tab_image = st.file_uploader("Upload tablet", type=["jpg", "png", "jpeg"])
    if st.button("Identify Tablet"):
        if tab_image:
            with open("tablet.jpg", "wb") as f:
                f.write(tab_image.read())
            info = identify_tablet("tablet.jpg")
            st.json(info)
