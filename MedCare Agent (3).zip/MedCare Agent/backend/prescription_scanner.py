import base64, re, json, pandas as pd
from backend.config import client
from backend.telegram_utils import send_telegram_message

df = pd.read_csv("backend/medicine_dataset.csv")

def clean_json_response(text):
    text = re.sub(r"^```(?:json)?", "", text.strip(), flags=re.IGNORECASE)
    text = re.sub(r"```$", "", text.strip())
    text = text.replace("'", '"')
    return text.strip()

def extract_prescription_data(image_path):
    with open(image_path, "rb") as f:
        image_bytes = f.read()
    image_base64 = base64.b64encode(image_bytes).decode("utf-8")

    response = client.responses.create(
        model="gpt-4o-mini",
        input=[{
            "role": "user",
            "content": [
                {"type": "input_text", "text": (
                    "Extract all medicine names, dosage, and timing. "
                    "Return JSON like: {'medicines':[{'name':'Paracetamol','dosage':'500mg','time':'Morning'}]}"
                )},
                {"type": "input_image", "image_url": f"data:image/jpeg;base64,{image_base64}"}
            ]
        }],
        max_output_tokens=500
    )
    return response.output_text

def process_prescription(image_path):
    print(f"🩺 Processing: {image_path}")
    raw = extract_prescription_data(image_path)
    cleaned = clean_json_response(raw)

    try:
        data = json.loads(cleaned)
        meds = data.get("medicines", [])
        if not meds:
            print("⚠ No medicines found.")
            return
        for m in meds:
            send_telegram_message(m["name"], m["dosage"], m["time"])
    except json.JSONDecodeError:
        print("⚠ Invalid JSON output:", raw)
